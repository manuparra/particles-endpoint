import connexion
import six

from swagger_server.models.particles import Particles  # noqa: E501
from swagger_server import util


def lookupparticles(lookup, species=None):  # noqa: E501
    """Lookup by the partial name of the particles

    Search name of the particles by a partial string # noqa: E501

    :param lookup: Status values that need to be considered for filter
    :type lookup: str
    :param species: Species of the particle
    :type species: str

    :rtype: List[Particles]
    """
    return 'do some magic!'
