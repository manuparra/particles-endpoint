# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.particles import Particles  # noqa: E501
from swagger_server.test import BaseTestCase


class TestParticleController(BaseTestCase):
    """ParticleController integration test stubs"""

    def test_lookupparticles(self):
        """Test case for lookupparticles

        Lookup by the partial name of the particles
        """
        query_string = [('lookup', 'lookup_example'),
                        ('species', 'species_example')]
        response = self.client.open(
            '//particle/',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
